#ifndef	SUSOFTWAREUPDATEERRORS_h
#define	SUSOFTWAREUPDATEERRORS_h	1

extern NSString * const SUSoftwareUpdateErrorDomain;

enum {

	SUSoftwareUpdateCheckFailedError = 1000, /* Generic failure - look at underlying error key */
	SUSoftwareUpdateCouldNotExtractUpdatePackage,
	SUSoftwareUpdatePackageFailedChecksum,
	SUSoftwareUpdateFeedDownloadFailedError,
	SUSoftwareUpdatePayloadDownloadFailedError,
};

#endif

