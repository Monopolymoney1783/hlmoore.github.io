#ifndef	SUCONVERSIONUTILITIES_h
#define	SUCONVERSIONUTILITIES_h	1

#ifdef	__cplusplus
extern "C"
{
#endif

OSType OSTypeFromNSString(NSString *string);
NSString * NSStringFromOSType(OSType fourCharCode);

#ifdef __cplusplus
}
#endif

#endif
