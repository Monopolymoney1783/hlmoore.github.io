#ifndef	SUFEEDDOWNLOAD_h
#define	SUFEEDDOWNLOAD_h	1

@protocol SUFeedDownloadDelegate;

@interface SUFeedDownload : NSObject {
@private
	id<SUFeedDownloadDelegate> _delegate;
	NSURL *_feedURL;
	NSString *_userAgent;
	NSURLSessionDataTask *_downloadTask;
	NSURLResponse *_response;
	NSData *_data;
}

- (instancetype)initWithFeedURL:(NSURL *)feedURL userAgent:(NSString *)userAgent delegate:(id<SUFeedDownloadDelegate>)delegate;
- (void)startFeedDownload;

- (id<SUFeedDownloadDelegate>)delegate;
- (void)setDelegate:(id<SUFeedDownloadDelegate>)delegate;

- (NSURLResponse *)response;
- (NSData *)data;

@end

@protocol SUFeedDownloadDelegate
- (void)feedDownloadDidFinish:(SUFeedDownload *)download;
- (void)feedDownload:(SUFeedDownload *)download didFailWithError:(NSError *)error;
@end

#endif

