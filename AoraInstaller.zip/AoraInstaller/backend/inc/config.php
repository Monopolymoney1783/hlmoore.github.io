<?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','password');
define('DB_NAME','Aora');
define('DB_PORT','3306');


try {
    //create PDO connection 
    $db = new PDO("mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e) {
    //show error
    echo '<center><div class="alert alert-danger">'.$e->getMessage().'</div></center>';
    exit;
}



?>
