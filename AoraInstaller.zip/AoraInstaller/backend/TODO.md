TODO:

- Work work work ughhhhhh
- Add some sort of caching mechanism? maybe later (lets just use cloudflare)
- Smonke that dank
