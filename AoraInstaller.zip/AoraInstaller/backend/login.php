<?php
require('inc/config.php');


// I'll finish this later, promise


?>
