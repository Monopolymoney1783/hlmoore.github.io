//
//  TableViewController.m
//  TableViewDemo
//
//  Created by Henry Moore on 08/02/18.
//  Copyright © 2018 Henry Moore. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()
{
    NSArray *packages;
    NSMutableArray *filteredPackages;
    BOOL isFiltered;
}
@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isFiltered = false;
    self.searchBar.delegate = self;
    
    packages = @[@"Aora",@"OpenSSH",@"Anemone",@"XenHTML",@"Lotus", @"Serendipity"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        isFiltered = false;
    }
    else {
        isFiltered = true;
        filteredPackages = [[NSMutableArray alloc]init];
        
        for (NSString *package in packages) {
            NSRange namerange = [package rangeOfString:searchText options:NSCaseInsensitiveSearch];
            if (namerange.location != NSNotFound) {
                [filteredPackages addObject:package];
            }
        }
    }
    [self.tableView reloadData];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self.view endEditing:YES];
    

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (isFiltered == true) {
        return filteredPackages.count;
    }
    return packages.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    if (isFiltered == true) {
        cell.backgroundColor = [UIColor blackColor];
        cell.textLabel.textColor = [UIColor whiteColor];
         cell.textLabel.text = filteredPackages[indexPath.row];
    }
    else {
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.text = packages[indexPath.row];
    }
    
    return cell;
}




@end
