//
//  ViewController.m
//  Aora
//
//  Created by Trilo on 7/31/18.
//  Copyright © 2018 trilo. All rights reserved.
//

#import "ViewController.h"
#include <spawn.h>


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *packagebackground;
@property (weak, nonatomic) IBOutlet UILabel *PackageName;

@property (weak, nonatomic) IBOutlet UILabel *iosversion;
@property (weak, nonatomic) IBOutlet UILabel *device;
@property (weak, nonatomic) IBOutlet UIImageView *PackageIcon;

@property (weak, nonatomic) IBOutlet UIImageView *PackageScreen;

@property (weak, nonatomic) IBOutlet UIButton *installBtn;

//@property (weak, nonatomic) IBOutlet UISwitch *darkMode;
@property (weak, nonatomic) IBOutlet UIImageView *packIcon;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UILabel *packagedisctext;
//@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *labels;
//@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *views;

@end

@implementation ViewController

/*(UIImage *)imageFromLayer:(CALayer *)layer
{
    UIGraphicsBeginImageContext([layer frame].size);
    
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *outputImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return outputImage;
}*/

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSURLCache sharedURLCache] removeAllCachedResponses];

    // Do any additional setup after loading the view, typically from a nib.
    
    /*CAGradientLayer *gradient = [CAGradientLayer layer];
    
    gradient.frame = self.navigationController.navigationBar.bounds;
    
    gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor blackColor] CGColor], nil];
    
    [self.navigationController.navigationBar setBackgroundImage:[self imageFromLayer:gradient] forBarMetrics:UIBarMetricsDefault];*/
    
    
    NSURL *url = [NSURL URLWithString:@"https://AoraInstaller.github.io/PackageName.txt"];
    NSError* error;
    NSString *content = [NSString stringWithContentsOfURL:url encoding:NSASCIIStringEncoding error:&error];
    _PackageName.text = content;
    NSData * PackageiconURL = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://AoraInstaller.github.io/PackageIcon.jpg"]];
    NSData * PackageScreenshotURL = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://AoraInstaller.github.io/PackageScreenshot.png"]];
    _PackageScreen.image = [UIImage imageWithData: PackageScreenshotURL];
    _PackageScreen.layer.masksToBounds = true;
    _PackageScreen.layer.cornerRadius = 15;
    _PackageIcon.image = [UIImage imageWithData:PackageiconURL];
    _PackageIcon.layer.cornerRadius = 15;
    _PackageIcon.layer.masksToBounds = true;
    _packagebackground.layer.cornerRadius = 15;
    _packagebackground.layer.masksToBounds = true;
    [_iosversion setText:[[UIDevice currentDevice] systemVersion]];
    [_device setText:[[UIDevice currentDevice] name]];
    _installBtn.layer.cornerRadius = 15;
    _packIcon.image = [UIImage imageWithData:PackageiconURL];
    _packIcon.layer.cornerRadius = 20;
    _packIcon.layer.masksToBounds = true;
    NSString *urlString = @"https://aorainstaller.github.io/home.html";
    NSURL *homeurl = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:homeurl];
    [_webView loadRequest:urlRequest];
    [_webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitUserSelect='none';"];
    // Disable callout
    [_webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitTouchCallout='none';"];
    
}
/*- (IBAction)toggleDark:(id)sender {
    if(_darkMode.on){
        for(UILabel *label in _labels){
            label.textColor = UIColor.whiteColor;
        }
        for(UIView *view in _views){
            view.backgroundColor = [UIColor colorWithRed:0.12 green:0.12 blue:0.12 alpha:1.0];
        }
        _installBtn.backgroundColor = [UIColor colorWithRed:0.3 green:0.3 blue:0.3 alpha:1.0];
        _installBtn.tintColor = UIColor.whiteColor;
    }
    else{
        for(UILabel *label in _labels){
            label.textColor = UIColor.blackColor;
        }
        for(UIView *view in _views){
            view.backgroundColor = UIColor.whiteColor;
        }
        _installBtn.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:1.0];
        _installBtn.tintColor = UIColor.blackColor;
    }
}*/
- (IBAction)installbutton:(id)sender {
    pid_t pid;
    int status;
    const char *argv[] = {"nuke", "-i", "/var/mobile/tweak.deb", NULL};
        posix_spawn(&pid, "/usr/bin/nuke", NULL, NULL, (char**)argv, NULL);
        waitpid(pid, &status, 0);
   
        // Respring Function
        const char *argvc[] = {"killall", "-9", "backboardd", NULL};
        posix_spawn(&pid, "/usr/bin/killall", NULL, NULL, (char**)argvc, NULL);
        waitpid(pid, &status, 0);
}

@end
