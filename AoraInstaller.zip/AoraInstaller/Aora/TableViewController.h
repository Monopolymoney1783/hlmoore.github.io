//
//  TableViewController.h
//  TableViewDemo
//
//  Created by Mukesh Kumar on 03/03/17.
//  Copyright © 2017 Mukesh Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@end
