//
//  main.m
//  Aora
//
//  Created by Trilo on 7/31/18.
//  Copyright © 2018 trilo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
