TO SIGN UR OWN BINARY:

```ldid -Sentitlements.xml nuke11```
